# 📱 منصة جسور المعرفة — دليل تحويل APK Android

## ✅ الحالة: PWA جاهز للتثبيت على Android مباشرة!

---

## 🚀 الطريقة 1 — التثبيت الفوري (الأسرع — بدون برمجة)

### على هاتف Android:
1. افتح الملف `index.html` على خادم محلي أو ارفعه على GitHub Pages
2. افتح الرابط في متصفح **Chrome**
3. ستظهر رسالة **"تثبيت جسور المعرفة"** في أسفل الشاشة
4. اضغط **✅ تثبيت**
5. سيُضاف التطبيق لشاشتك الرئيسية مثل أي APK !

### رفع مجاني على GitHub Pages:
```bash
# 1. أنشئ repository جديد على github.com
# 2. ارفع محتوى مجلد josour-app/
# 3. فعّل GitHub Pages في Settings
# 4. الرابط: https://username.github.io/josour-app/
```

---

## 🔨 الطريقة 2 — بناء APK حقيقي بـ Capacitor

### المتطلبات:
- Node.js 18+
- Android Studio (مجاني من developer.android.com)
- Java JDK 17+

### الخطوات:

```bash
# 1. إنشاء مشروع Capacitor
npm init @capacitor/app josour-android
cd josour-android

# 2. نسخ ملفات التطبيق
cp -r /path/to/josour-app/* src/

# 3. تثبيت Capacitor Android
npm install @capacitor/core @capacitor/android
npx cap init "جسور المعرفة" com.zahrawy.josour --web-dir src
npx cap add android

# 4. مزامنة الملفات
npx cap sync android

# 5. بناء APK
cd android
./gradlew assembleDebug

# APK جاهز في: android/app/build/outputs/apk/debug/app-debug.apk
```

---

## ⚡ الطريقة 3 — PWA to APK أونلاين (بدون برمجة)

### مواقع تحوّل PWA → APK مجاناً:

| الموقع | المميزات | الرابط |
|--------|---------|--------|
| **PWABuilder** | مجاني — من Microsoft | pwabuilder.com |
| **Bubblewrap** | Google أداة رسمية | github.com/GoogleChromeLabs/bubblewrap |
| **AppMaker** | واجهة بسيطة | gonative.io |

### باستخدام PWABuilder:
1. ارفع التطبيق على أي خادم (GitHub Pages مجاناً)
2. افتح pwabuilder.com
3. أدخل رابط التطبيق
4. اضغط **Build** → **Android**
5. حمّل APK جاهز!

---

## 📁 هيكل الملفات الجاهزة

```
josour-app/
├── index.html          ← التطبيق الرئيسي (v18 كامل)
├── manifest.json       ← إعدادات PWA
├── sw.js               ← Service Worker (وضع أوفلاين)
└── icons/
    ├── icon-48x48.png
    ├── icon-72x72.png
    ├── icon-96x96.png
    ├── icon-128x128.png
    ├── icon-144x144.png
    ├── icon-152x152.png
    ├── icon-192x192.png
    ├── icon-384x384.png
    ├── icon-512x512.png
    ├── icon-maskable-192.png
    └── icon-maskable-512.png
```

---

## 📝 capacitor.config.json

```json
{
  "appId": "com.zahrawy.josour",
  "appName": "جسور المعرفة",
  "webDir": "src",
  "bundledWebRuntime": false,
  "android": {
    "allowMixedContent": true,
    "captureInput": true,
    "webContentsDebuggingEnabled": false,
    "backgroundColor": "#1B3A6B",
    "minSdkVersion": 22,
    "targetSdkVersion": 34,
    "compileSdkVersion": 34
  },
  "plugins": {
    "SplashScreen": {
      "launchShowDuration": 2000,
      "backgroundColor": "#1B3A6B",
      "androidSplashResourceName": "splash",
      "showSpinner": false
    },
    "StatusBar": {
      "style": "DARK",
      "backgroundColor": "#1B3A6B",
      "overlaysWebView": false
    },
    "Keyboard": {
      "resize": "body",
      "resizeOnFullScreen": true
    }
  }
}
```

---

## 🎨 Android Strings (android/app/src/main/res/values/strings.xml)

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">جسور المعرفة</string>
    <string name="title_activity_main">جسور المعرفة</string>
    <string name="package_name">com.zahrawy.josour</string>
    <string name="custom_url_scheme">com.zahrawy.josour</string>
</resources>
```

---

## 🔑 توقيع APK للنشر على Google Play

```bash
# إنشاء مفتاح التوقيع
keytool -genkey -v -keystore josour-release.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias josour-key \
  -dname "CN=Zahrawy, OU=Education, O=Josour, L=Khenifra, S=Beni Mellal, C=MA"

# بناء APK موقّع
cd android
./gradlew assembleRelease \
  -Pandroid.injected.signing.store.file=josour-release.jks \
  -Pandroid.injected.signing.store.password=YOUR_PASSWORD \
  -Pandroid.injected.signing.key.alias=josour-key \
  -Pandroid.injected.signing.key.password=YOUR_PASSWORD
```

---

## 📱 مواصفات التطبيق

- **الاسم:** جسور المعرفة
- **الحزمة:** com.zahrawy.josour
- **الإصدار:** 18.0
- **Android الأدنى:** 6.0 (API 23)
- **الهدف:** Android 14 (API 34)
- **الحجم التقريبي:** ~2MB (APK)
- **الوضع:** Standalone (كامل الشاشة بدون شريط المتصفح)
- **اللون الأساسي:** #1B3A6B (أزرق داكن)
- **يعمل أوفلاين:** ✅ نعم (Service Worker)
- **الاتجاه:** Portrait (عمودي)

---

## ⭐ مزايا PWA vs APK الكلاسيكي

| الميزة | PWA | APK |
|--------|-----|-----|
| تثبيت بدون متجر | ✅ | ❌ |
| يعمل أوفلاين | ✅ | ✅ |
| تحديث تلقائي | ✅ | ❌ (يدوي) |
| حجم خفيف | ✅ ~750KB | ❌ عادة 10MB+ |
| Google Play | ❌ يحتاج APK | ✅ |
| بدون Android Studio | ✅ | ❌ |

---

*منصة جسور المعرفة v18 — ذ. عبد الواحد يوسفي — الزهراوي الرائدة — 2026*
